from django.db import models

class FaceProfile(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100, blank=True)
    email = models.EmailField(unique=True)
    encoding = models.BinaryField()
    photo = models.ImageField(upload_to='faces/', blank=True, null=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}".strip()

    @property
    def photo_url(self):
        if self.photo:
            return self.photo.url
        return "/static/default_avatar.png" 
