import base64
from io import BytesIO
from PIL import Image
from django.core.files.base import ContentFile
import pickle
from rest_framework.views import APIView
from rest_framework.response import Response
from .utils import face_recognizer 
from rest_framework import status
from .models import FaceProfile
from .serializers import RegisterSerializer
from .utils.face_recognizer import FaceRecognizer
from django.conf import settings
import traceback
from django.shortcuts import render

face_recognizer = FaceRecognizer()


def camera_test(request):
    return render(request, 'test/camera_test.html')

class RegisterView(APIView):
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            data = serializer.validated_data

            image_b64 = data.get("image_data")
            try:
                image_bytes = base64.b64decode(image_b64.split(',')[-1])
                image = Image.open(BytesIO(image_bytes)).convert('RGB')
            except Exception as e:
                return Response({"error": f"Invalid image data: {str(e)}"}, status=400)

            embedding = face_recognizer.get_face_embedding(image)
            if embedding is None:
                return Response({"error": "No face detected"}, status=400)

            # save image to file
            file_name = f"{data['first_name']}_{data['email'].split('@')[0]}.jpg"
            photo_file = ContentFile(image_bytes, name=file_name)

            profile = FaceProfile.objects.create(
                first_name=data["first_name"],
                last_name=data.get("last_name", ""),
                email=data["email"],
                encoding=pickle.dumps(embedding),
                photo=photo_file
            )

            return Response({
                "message": "User registered successfully",
                "photo_url": request.build_absolute_uri(profile.photo.url) if profile.photo else None
            }, status=201)

        return Response(serializer.errors, status=400)


class VerifyView(APIView):
    def post(self, request):
        serializer = VerifyImageSerializer(data=request.data)
        if serializer.is_valid():
            image_b64 = serializer.validated_data['image_data']
            try:
                image_bytes = base64.b64decode(image_b64.split(',')[-1])
                image = Image.open(BytesIO(image_bytes)).convert('RGB')
            except Exception as e:
                return Response({"error": f"Invalid image data: {str(e)}"}, status=400)

            unknown_embedding = face_recognizer.get_face_embedding(image)
            if unknown_embedding is None:
                return Response({'error': 'No face detected'}, status=400)

            best_match = None
            best_score = 0

            for profile in FaceProfile.objects.all():
                known_embedding = pickle.loads(profile.encoding)
                similarity = face_recognizer.compare_faces(known_embedding, unknown_embedding)
                if similarity > best_score:
                    best_score = similarity
                    best_match = profile

            tolerance = getattr(settings, 'FACE_RECOGNITION_TOLERANCE', 0.6)

            if best_match and best_score >= tolerance:
                return Response({
                    "match": True,
                    "id": best_match.id,
                    "email": best_match.email,
                    "first_name": best_match.first_name,
                    "last_name": best_match.last_name,
                    "similarity": round(best_score, 3),
                    "photo_url": best_match.photo.url if best_match.photo else None
                }, status=200)

            return Response({
                "match": False,
                "message": "No match found",
                "best_similarity": round(best_score, 3)
            }, status=404)

        return Response(serializer.errors, status=400)


class StreamVerifyView(APIView):
    """
    Handles live video frame input and returns recognized faces (multiple supported).
    """

    def post(self, request):
        image_b64 = request.data.get('image_data')

        if not image_b64:
            return Response({"error": "No image data provided"}, status=400)

        try:
            # Decode Base64 image
            image_bytes = base64.b64decode(image_b64.split(',')[-1])
            img_stream = BytesIO(image_bytes)
            image = Image.open(img_stream).convert('RGB')
            image.load()
        except Exception as e:
            return Response({"error": f"Invalid image data: {str(e)}"}, status=400)

        try:
            from facenet_pytorch import MTCNN
            import torch

            mtcnn = MTCNN(keep_all=True, device=torch.device('cpu'))
            boxes, _ = mtcnn.detect(image)

            if boxes is None:
                return Response({"message": "No faces detected"}, status=200)

            results = []
            tolerance = getattr(settings, 'FACE_RECOGNITION_TOLERANCE', 0.6)

            for box in boxes:
                left, top, right, bottom = [int(v) for v in box]
                cropped = image.crop((left, top, right, bottom))

                face_embedding = face_recognizer.get_face_embedding(cropped)
                if face_embedding is None:
                    continue

                best_match = None
                best_score = 0.0

                for profile in FaceProfile.objects.all():
                    if not profile.encoding:
                        continue
                    try:
                        known_embedding = pickle.loads(profile.encoding)
                        similarity = face_recognizer.compare_faces(known_embedding, face_embedding)
                    except Exception:
                        continue

                    if similarity > best_score:
                        best_score = similarity
                        best_match = profile

                # Build response
                if best_match and best_score >= tolerance:
                    # ✅ Use the correct field name: `photo`
                    photo_url = (
                        request.build_absolute_uri(best_match.photo.url)
                        if best_match.photo and hasattr(best_match.photo, 'url')
                        else request.build_absolute_uri("/static/avatar.png")
                    )

                    results.append({
                        "name": f"{best_match.first_name} {best_match.last_name}",
                        "email": best_match.email,
                        "photo_url": photo_url,
                        "similarity": round(best_score, 3)
                    })
                else:
                    results.append({
                        "name": "Unknown User",
                        "email": None,
                        "photo_url": request.build_absolute_uri("/static/avatar.png"),
                        "similarity": round(best_score, 3)
                    })

            return Response(results, status=200)

        except Exception as e:
            print("---- STREAM VERIFY ERROR ----")
            traceback.print_exc()
            print("---- END ERROR ----")
            return Response({"error": f"Recognition error: {str(e)}"}, status=500)
