from rest_framework import serializers
from .models import FaceProfile

class RegisterSerializer(serializers.ModelSerializer):
    image_data = serializers.CharField(write_only=True)

    class Meta:
        model = FaceProfile
        fields = ['first_name', 'last_name', 'email', 'image_data']


class VerifyImageSerializer(serializers.Serializer):
    image_data = serializers.CharField()
