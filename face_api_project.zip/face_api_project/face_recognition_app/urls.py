from django.urls import path
from . import views

urlpatterns = [
    path('test/camera/', views.camera_test, name='camera_test'),

    # API endpoints
    path('api/register/', views.RegisterView.as_view(), name='register'),
    path('api/verify/', views.VerifyView.as_view(), name='verify'),
    path('api/stream_verify/', views.StreamVerifyView.as_view(), name='stream_verify'),
]
