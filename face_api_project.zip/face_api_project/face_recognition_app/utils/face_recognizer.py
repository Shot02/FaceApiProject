import torch
import numpy as np
import base64
import cv2
import logging
from io import BytesIO
from PIL import Image
from facenet_pytorch import MTCNN, InceptionResnetV1

logger = logging.getLogger(__name__)

class FaceRecognizer:
    def __init__(self):
        self.device = torch.device('cpu')
        self.mtcnn = MTCNN(keep_all=False, device=self.device)
        self.resnet = InceptionResnetV1(pretrained='vggface2').eval().to(self.device)
        logger.info("FaceRecognizer ready (CPU mode)")

    def _base64_to_image(self, base64_str):
        try:
            header, data = base64_str.split(',', 1)
            image_data = base64.b64decode(data)
            img = Image.open(BytesIO(image_data)).convert('RGB')
            return img
        except Exception as e:
            logger.error(f"Base64 decode error: {e}")
            return None

    def get_face_embedding(self, image_data):
        try:
            # If it's a base64 string, decode it
            if isinstance(image_data, str):
                img = self._base64_to_image(image_data)
            # If it's already a PIL Image
            elif isinstance(image_data, Image.Image):
                img = image_data
            else:
                logger.error("Unsupported image input type")
                return None

            if img is None:
                logger.error("Image conversion failed")
                return None

            face = self.mtcnn(img)
            if face is None:
                logger.warning("No face detected in image")
                return None

            with torch.no_grad():
                embedding = self.resnet(face.unsqueeze(0).to(self.device))

            embedding_np = embedding.cpu().numpy().flatten().astype(np.float32)
            norm = np.linalg.norm(embedding_np)
            return embedding_np / norm if norm > 0 else embedding_np

        except Exception as e:
            logger.error(f"Error extracting embedding: {e}")
            return None

    def compare_faces(self, known_embedding, unknown_embedding):
        try:
            known = np.array(known_embedding, dtype=np.float32)
            unknown = np.array(unknown_embedding, dtype=np.float32)
            similarity = np.dot(known, unknown) / (
                np.linalg.norm(known) * np.linalg.norm(unknown)
            )
            return float(similarity)
        except Exception as e:
            logger.error(f"Error comparing faces: {e}")
            return 0.0
